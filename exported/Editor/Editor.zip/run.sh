java -Dorg.lwjgl.librarypath=linux -cp Editor.jar:HamPieEngine.jar:lwjgl.jar editor.Editor
